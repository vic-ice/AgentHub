# AgentHub 项目技术事实材料（本科毕业设计论文写作版）

> 基准日期：2026-08-28
> 代码基准：分支 `codex/search-deepresearch-quality`，生产实现提交 `054198dd5ff6cd761377066a3cc95daf010f039f`
> 验证结果：后端 `691 passed, 38 subtests passed`；前端 `npm run build` 成功
> 用途：向论文作者提供可由当前代码、数据库脚本和测试复核的技术事实。本文不是宣传材料，不把设想、兼容代码或有条件能力写成已经稳定实现的功能。

---

## 0. 使用规则与事实口径

### 0.1 事实来源优先级

本文按以下顺序判断项目现状：

1. 当前工作区生产入口和实际运行代码；
2. 当前数据库模型与 backend/scripts/sql 中的迁移脚本；
3. 当前自动化测试、架构门禁和可执行验证脚本；
4. docs/SYSTEM_ARCHITECTURE.md 等架构契约；
5. README、历史材料和旧提交仅作背景，不作为当前事实。

### 0.2 状态术语

| 状态 | 含义 |
|---|---|
| 已实现 | 存在当前生产入口、真实实现和相应数据结构，可在依赖就绪时运行 |
| 有条件实现 | 代码已经接通，但依赖外部模型、搜索服务、网络、数据库或用户配置 |
| 内部能力 | 已有后端契约或运行组件，但不是当前普通用户界面的主要功能 |
| 兼容保留 | 代码仍在仓库中，只用于旧测试、迁移或隔离兼容，不是权威生产主链 |
| 未实现 | 当前代码无法支持，不应在论文中使用完成式表述 |

### 0.3 不能混淆的三个概念

- “代码存在”不等于“当前生产入口会调用”。例如旧 MemoryCommitter 仍有兼容代码，但 Agent Core、Chat、API 和 Tool 的权威写入链不能调用它。
- “单次语义理解”不等于“一轮对话只调用一次 LLM”。普通 Chat 的第一轮 Controller 可以一次输出多个结构化动作，Memory/Reading 不再调用第二个 LLM 重复理解同一句话；但工具执行后，Controller 为继续决策或综合结果最多可进行 6 个受限回合。
- “测试脚本存在”不等于“所有真实外部 E2E 在任意时刻都通过”。依赖模型和网络的验证可能受额度、超时和第三方页面变化影响。
- “检索增强”不等于“外部材料取代模型能力”。当前收敛原则是：模型负责理解、候选判断和最终综合，工具负责补充可变、精确和可核验的信息；如果管道使最终答案稳定弱于模型直接回答，就属于反向增强，需要在执行或发布边界修复。

---

## 1. 项目定位

AgentHub 是一个面向阅读场景的、具有长期记忆和工具执行能力的 Web 智能助手。它把自然语言对话、书架管理、个性化图书推荐和独立深度研究放在同一用户空间中，同时保留模型配置、研究状态、执行轨迹和用量统计等工程管理能力。

最能体现项目目标的用户效果是：

> 用户说“读完《失控》，不太喜欢；准备开始《必然》”，系统应一次理解出多个相互独立的业务事实，更新两本书的书架状态和评价，形成可追溯的阅读事件与长期记忆；之后普通推荐不再把这些已知书当作新书；只有用户主动开启 Deep Research 时，系统才进入独立的研究流程。

项目当前主要解决五类问题：

1. 多轮对话与流式响应；
2. 长期事实、偏好和实体的版本化记忆；
3. 用户阅读资产的权威书架管理；
4. 同时利用 Memory 与 Shelf 的个性化图书推荐；
5. 与普通 Chat 隔离的检索、证据和报告型 Deep Research。

它不是一个已经商业化的通用知识库，也不是完全自治、无限循环的多智能体平台。当前认证以本地模拟用户为主，外部搜索和模型能力依赖配置，研究循环也有明确预算上限。

---

## 2. 总体架构

### 2.1 分层原则

项目当前的权威业务链遵循：

~~~text
用户 / 前端 / API / Tool / 后台任务
→ Semantic / Intent（理解用户目标，提出结构化动作）
→ 唯一 Domain Service / Gateway（业务决策与编排）
→ 内部组件（解析、投影、校验、排序、渲染）
→ Runtime / Store / Provider（执行、版本、持久化契约）
→ PostgreSQL / 本地文件 / 外部系统
~~~

规则代码用于类型校验、权限边界、幂等、冲突检查和失败兜底，不用关键词规则替代 LLM 对自然语言的理解。Store、Provider 和数据库层不重新解释用户语义。

### 2.2 系统组件图

~~~mermaid
flowchart TB
    U["用户"] --> FE["React 19 Web 前端"]
    FE -->|"REST / SSE / WebSocket"| API["FastAPI API 层"]

    API --> CHAT["ChatService"]
    API --> DOMAINAPI["Bookshelf / Memory / Research / Config API"]

    CHAT --> MODE{"research_mode"}
    MODE -->|"chat"| AG["AgentChatEntry → AgentControllerGateway"]
    MODE -->|"deep_research"| DR["DeepResearchRunner"]

    AG --> CTX["ControllerRequestBuilder<br/>Memory / Shelf 有界上下文"]
    CTX --> CTRL["ControllerClient<br/>语义理解与动作提议"]
    CTRL --> EXEC["Capability Registry → Compiler → Runtime"]
    EXEC --> MWG["MemoryWriteGateway"]
    EXEC --> RS["ReadingService"]
    EXEC --> REC["RecommendationService"]
    EXEC --> SG["SearchGateway"]

    DOMAINAPI --> RS
    DOMAINAPI --> MWG
    DOMAINAPI --> MRG["MemoryReadGateway"]
    DOMAINAPI --> RO["ResearchOrchestrator"]

    MWG --> MFE["EntityResolver + ModelFactExecutor"]
    MFE --> VS["MemoryVersionStore"]
    VS --> MP["Postgres Memory Provider"]
    RS --> PG[("PostgreSQL")]
    REC --> MRG
    REC --> RS
    REC --> SG
    MRG --> MCP["CurrentProjection<br/>当前语义收敛"]
    MCP --> PG
    MP --> PG
    RO --> PG
    DR --> SG
    DR --> RO

    RS --> META["BookMetadata 外部元数据组件"]
    META --> DBAN["豆瓣图书页面 / 图片源"]
    META --> COVER["本地封面缓存"]
    SG --> EXT["Tavily / DDGS / AnySearch 等"]

    CHAT --> PUB["可信发布、SSE、Trace、Usage"]
    PUB --> PG
~~~

### 2.3 每个领域的权威 Owner 与 Source of Truth

| 领域 | 权威业务 Owner | 权威读取 | Source of Truth |
|---|---|---|---|
| 普通对话 | ChatService、AgentControllerGateway | Conversation Journal / History | conversations、conversation_events |
| 语义与动作提议 | ControllerClient | Controller request context | 结构化 Controller 输出，不直接持久化 |
| Memory 写入 | MemoryWriteGateway | — | memory_events 的当前版本头与版本链 |
| Memory 读取/画像 | MemoryReadGateway | current semantic projection / history / search / profile | memory_events；历史行不因当前投影而删除 |
| Entity 绑定 | EntityResolver（内部组件） | current entity facts | memory_entities 与实体型 memory facts |
| 阅读状态与评价 | ReadingService | Shelf current view / reading anchors | user_book_shelf；事件表仅作历史与信号 |
| 个性化推荐 | ControllerRequestBuilder + RecommendationService | 有界 Shelf 上下文 + Recommendation projection | 模型候选 + 外部核验 + Memory + Shelf + recommendation events |
| 公共搜索 | SearchGateway + Agent Core publication | UserAnswerBrief / ExternalAnswerView | 外部结果、typed receipt 与本地 books 缓存 |
| Deep Research | DeepResearchRunner + ResearchOrchestrator | ResearchRun aggregate + ResearchPublicationPacket | research_runs/steps/evidence/state_snapshots/report |
| 工具执行 | Agent Core Harness / System Runtime | typed action receipts | action receipt、trace 与相应领域数据 |
| 模型与 Provider 配置 | Models / Provider Config API + CRUD/Repository | 配置查询 API | providers、provider_connections、models、app_provider_configs |
| Trace 与用量 | Trusted publication / execution progress | Trace API / stats API | trace_executions、conversation usage fields |

Memory 与 Shelf 的边界尤其重要：Memory 表示可用于理解和个性化的长期事实；Shelf 表示用户当前“想读、在读、已读、弃读”及单书评价。询问“我的书架有哪些书”时必须读取 Shelf，不能从自然语言记忆拼凑答案。

---

## 3. 普通 Chat 的真实执行链

### 3.1 请求入口

前端通过：

- POST /api/v1/chat/invoke 获取一次性响应；
- POST /api/v1/chat/stream 获取 SSE 流式响应。

API 只负责校验请求、保证会话存在并调用 ChatService。ChatService 先把用户输入写入 Conversation Journal，再根据 research_mode 选择普通 Chat 或 Deep Research。

前端创建会话与立即发起流式请求可能并发到达。`get_or_create_conversation_by_thread_id()` 使用嵌套事务处理唯一键竞争；若另一事务已创建同一会话，则读取胜出的记录继续执行，而不是把安全并发变成 500 错误。

### 3.2 普通 Chat 主链

~~~mermaid
sequenceDiagram
    participant U as 用户
    participant C as ChatService
    participant J as ConversationJournal
    participant G as AgentControllerGateway
    participant L as ControllerClient
    participant H as Harness/Compiler/Runtime
    participant D as Domain Service/Gateway
    participant P as Trusted Publisher

    U->>C: 自然语言消息
    C->>J: 记录用户事件
    C->>G: 构建当前模型与上下文
    G->>L: 一轮 Controller 决策
    L-->>G: direct / clarify / 0..N structured actions
    G->>H: 校验、编译、执行动作
    H->>D: 调用 Memory/Reading/Recommendation/Search 等 Owner
    D-->>H: typed receipts
    H-->>G: 执行结果
    alt 已有确定性答案
        G->>P: 发布回执支持的答案
    else 需要基于工具结果继续综合
        G->>L: 携带受信回执进入下一受限回合
    end
    P->>J: 记录助手消息、进度与用量
    P-->>U: HTTP 或 SSE 响应
~~~

Controller 每一回合只“提出动作”，不直接写数据库。动作必须存在于 Capability Registry，经过 ProposalValidator、Compiler 和 Runtime 后才能执行。工具结果以 typed receipt 返回，最终发布层优先生成“有回执支撑”的结果。

### 3.3 “一次理解，多业务动作”的实现

对输入：

> 读完《失控》，不太喜欢；准备开始《必然》

当前设计允许 Controller 在一次语义理解中输出一个包含多条 assertion 的 remember_memory 动作，assertion 至少可表达：

1. 《失控》的 reading_status = read；
2. 《失控》的 evaluation = disliked；
3. 《必然》的 reading_status = reading。

后续 compiled_turn_from_assertions 只把已经理解好的结构化 assertion 转成 0..N 个业务事实，不再调用 LLM，也不通过关键词重新猜测用户含义。不同事实可以分别成功或请求澄清，系统不会因其中一项有歧义而丢弃所有可执行项。

必须准确表述为：同一条自然语言在 Memory/Reading 写入前只经历一套语义解释；工具执行后的 Controller 仍可能基于回执继续下一回合，整个 Chat turn 的安全上限是 6 个 Controller 回合。

---

## 4. Memory、Entity 与 Reading 的统一写入

### 4.1 写入总图

~~~mermaid
flowchart LR
    A["Chat / Tool / Admin / Correction / System"] --> S["结构化事实或规范化管理请求"]
    S --> G["MemoryWriteGateway"]
    G -->|"非阅读事实"| E["EntityResolver<br/>同批实体绑定"]
    E --> X["ModelFactExecutor<br/>确定性协议执行"]
    X --> V["MemoryVersionStore"]
    G -->|"阅读事实"| R["ReadingService"]
    R --> SH[("user_book_shelf")]
    R --> EV[("recommendation_events / interaction audit")]
    R -->|"派生 reading memory"| G
    G --> V
    V --> P["PostgresMemoryProvider"]
    P --> ME[("memory_events")]
~~~

合法 provenance/source contract 包括：

- user_message
- reading_event
- tool_execution
- admin_action
- correction
- system_derived

MemoryWriteGateway 负责按事实类型路由、实体绑定、业务边界和统一回执。ModelFactExecutor 不调用 LLM、不重新阅读自然语言，只把模型已经给出的 subject/predicate/value 映射成注册 schema、稳定 identity 和 hash。MemoryVersionStore 只负责版本、supersede/tombstone、幂等与完整性；Postgres Provider 只执行持久化契约。

### 4.2 Memory 版本模型

同一 memory_key 的新事实不会简单覆盖旧行，而是形成版本链。当前版本作为有效 head，旧版本保留用于历史追溯；遗忘操作生成 tombstone，而不是直接删除所有历史。管理员可以：

- 查询用户当前有效记忆；
- 查询一个 memory key 的历史；
- 编辑/纠正事实；
- 忘记事实。

管理端编辑会先把表单事实规范化，然后仍通过 MemoryWriteGateway；管理端没有独立的数据库写入基线。

当前事实与物理版本头需要区分。历史版本曾把同一个对象名称写入不同 schema/key，系统不自动删除这些历史行，而由 CurrentProjection 在读取时按语义槽保留最新事实，并把旧结构投影为当前结构化协议。后续改名继续写入该对象最新的兼容版本链；历史接口仍可展示完整的“小花 → 咪咪”时间线。投影还会移除结构化事实中可能夹带旧名称的自由文本 summary，避免过期信息重新进入模型上下文。

### 4.3 Entity 作用

EntityResolver 把“失控”“《失控》”等表面名称绑定到稳定实体标识，避免同一本书因不同表达生成互不关联的事实。实体有歧义时返回澄清问题，不由 Store 或数据库猜测。

当前实体系统是面向用户事实绑定的轻量实体解析，并不是完整知识图谱或通用实体链接服务。

### 4.4 ReadingService 的职责

ReadingService 是用户阅读资产的权威 Owner，支持：

- want_to_read：想读；
- reading：在读；
- read：已读；
- dropped：弃读；
- liked、neutral、disliked、not_interested 或空评价；
- 备注与可选星级；
- 按标题或作者搜索；
- 从历史 recommendation event / interaction 一次性、幂等回填旧用户 Shelf。

一次 Reading 写入会更新当前 Shelf，并追加阅读/推荐信号事件；兼容 interaction 仍可作为审计材料。当前状态以 user_book_shelf 为准，不能从历史事件临时重放后当作当前答案。

自然语言中的明确阅读备注由 Controller assertion 的 `note` 字段进入同一 Reading 写链，不需要前端或规则层再次解析原句。移出书架时，ReadingService 会在同一事务中调用 `MemoryWriteGateway.forget_reading_memory()`，把该书当前的 `reading.state` / `reading.feedback` 投影写成 tombstone 后再删除 Shelf 条目；历史版本仍保留用于审计。

### 4.5 Reading 派生 Memory 的一致性边界

Chat 内的阅读事实由 MemoryWriteGateway → ReadingService → MemoryWriteGateway.record_reading_memory → MemoryVersionStore 完成。前端直接修改 Shelf 后，也只通过 write_reading_memory_best_effort 适配器重新进入 MemoryWriteGateway，不会直接调用 Memory Provider。

需要如实说明一个当前实现边界：REST Shelf 写入先提交权威 Shelf，再进行 best-effort Memory 投影，因此外部故障时可能出现“书架已成功、派生记忆暂时缺失”。这不会改变 Shelf 的权威状态，但当前没有跨两个事务的 outbox 自动补偿机制。

上述边界主要针对新增/修改后的派生写入。移出书架已经采用同事务的定向遗忘：当前阅读记忆会同步退出 CurrentProjection，但不会物理删除历史版本，也不会误删同名书籍以外的普通长期事实。

### 4.6 权威书架读取

Chat 询问“我书架里有哪些书、每本评价是什么”时走：

~~~text
Controller → bookshelf_read → bookshelf_read_v1
→ ReadingService.ensure_backfilled/list_entries
→ deterministic bookshelf renderer
~~~

该链不回退到 Memory，也不调用图书搜索伪造书架内容。前端“我的书架”同样读取 GET /api/v1/books/shelf/{user_id}。

---

## 5. 图书元数据、作者与封面

Shelf 列表读取时，ReadingService 会对缺少作者或本地封面的条目做有上限的并发补全，当前单次最多选择 12 条目标。外部元数据组件本身只做 I/O 和页面格式解析，没有 Shelf 或 Book 表写权限；最终持久化仍由 ReadingService 完成。

真实链路为：

~~~text
Shelf GET
→ ReadingService.enrich_missing_metadata
→ resolve_book_metadata(title)
→ 搜索候选并选择 book.douban.com/subject/{id}/
→ 解析 og:title、og:image、作者行或 JSON-LD
→ 下载允许的豆瓣图片（最大 8 MiB）
→ SHA-256 内容寻址写入 backend/data/book_covers
→ 保存应用内 /api/v1/books/covers/{hash}.{ext}
→ 前端长期显示本地 URL
~~~

本地封面接口设置一年 immutable cache。这样只在补全时依赖豆瓣，日常展示不直接把豆瓣当长期图床。

限制必须写入论文：豆瓣页面、搜索结果和网络不是受本项目控制的服务，解析可能失败；失败采用 fail-open，不修改阅读状态，前端显示“作者未知”或默认书籍图标。该功能不能被描述成拥有官方豆瓣 API 授权或保证所有书籍元数据正确。

---

## 6. 个性化推荐与普通搜索

本项目把普通 Search 定位为“一次高质量模型理解 + 并行/联合检索 + 一次面向用户的高质量综合”，不是固定多轮研究，也不是把搜索结果逐条拼接成答案。Controller 形成 UserAnswerBrief 与模型选择的 EvidenceStrategy；SearchGateway 负责外部 I/O、Provider 融合和去重；发布阶段只接收面向用户的 ExternalAnswerView/typed receipt，不接收研究控制状态。

### 6.1 两种 book_search 模式

Agent Core 的 book_search 能力有两个不同意图：

- mode=lookup：查找某一本书或目录信息，不应用个性化排除；
- mode=recommendation：寻找用户未知的新书，调用唯一 RecommendationService。

REST GET /api/v1/books/search 是公共目录搜索和本地缓存入口，不应在论文中等同于完整个性化推荐流水线。

### 6.2 推荐主链

~~~mermaid
flowchart LR
    Q["用户推荐请求"] --> B["ControllerRequestBuilder<br/>读取有界 Shelf 快照"]
    B --> C["Controller<br/>结合书架产生候选与检索意图"]
    C --> R["RecommendationService"]
    R --> M["MemoryReadGateway<br/>长期偏好"]
    R --> S["ReadingService<br/>Shelf snapshot + 已读锚点"]
    R --> G["SearchGateway / 本地 books cache"]
    M --> P["RecommendationProjector"]
    S --> P
    G --> P
    P --> F["排除、打分、排序、解释"]
    F --> V["TrustedPublisher<br/>综合 + 已核验候选覆盖"]
    V --> O["推荐结果与信号事件"]
~~~

推荐链在两个边界读取书架：ControllerRequestBuilder 只为推荐请求加载最多 20 条的有界快照，让模型在一次语义决策中直接理解用户已有书目并自主产生候选；RecommendationService 再读取完整 Shelf、Memory 和信号完成权威排重与排序。用户不需要重新复述书架，工具也不负责替代模型生成候选智能。

推荐服务读取两类个性化上下文：

1. Memory 中的长期偏好，如喜欢/不喜欢的作者、主题和风格；
2. Shelf 中的所有当前状态，以及“已读”书籍的作者、标签和评价锚点。

任何已经出现在 Shelf 中的书，无论想读、在读、已读还是弃读，都会从“新书推荐候选”中排除。评价为喜欢的已读书提供较强正向锚点，一般评价提供轻度正向，不喜欢或不感兴趣作为负向样本进行降权。Memory 中明确不喜欢的作者或风格也可造成降权或抑制。

对于“根据我的书架推荐”这类指代型请求，系统从正向 Shelf 条目选取少量标题作为发现锚点，生成“类似某书的新书”检索查询；这些锚点只帮助发现，不会绕过全量 Shelf 排重重新出现在最终结果中。

推荐结果仍受外部搜索候选质量影响。当前排序是应用层可解释的特征投影与权重组合，不是经过大规模离线训练并证明优于基线的推荐模型；若论文要声称推荐效果提升，必须另做用户实验或离线指标实验。

### 6.3 推荐反馈

系统记录 recommended、detail_requested、followup_clicked、liked、disliked、read 等 recommendation signal，用于后续衰减评分与解释。前端会在用户继续追问某本推荐书时记录正向交互信号。

仓库仍保留 /books/interactions 与 /books/recommendation-events 两个较底层的事件写入 API。它们属于交互/信号入口，不是 Shelf 当前状态的权威写入口；直接写这些事件不应被解释为已经修改书架。

### 6.4 Search 的模型增强与发布边界

Search 的最终答案允许同时使用两类信息：模型的稳定领域知识负责解释、比较和形成结论；外部检索用于核验会变化的事实、精确数字、来源和当前可用性。外部来源缺失不会自动删除模型本来能够合理给出的候选，但没有来源支撑的可变事实不能伪装成已核验事实。

工具回执先投影为面向回答的证据视图，再由模型做一次综合。若综合模型不可用，系统可以使用经过安全检查的确定性证据呈现；若工具没有形成可用回执而问题仍可由模型回答，则允许经过发布安全校验的模型知识回答。发布层检查空文本、伪造 URL、内部推理泄漏和协议安全，不把固定 Markdown 章节数量当作语义质量本身。

图书推荐的综合完成后还会执行 `complete_book_candidate_coverage()`：它只从本轮已经准入的 Response View 中补回被模型遗漏的候选，不创建新事实、不重新研究，也不改写模型主体判断。该机制修复“工具已经核验多本书，但最终答案只保留一两本”的反向压缩问题。

---

## 7. Deep Research

### 7.1 与普通 Chat 的隔离

Deep Research 只能由用户在当前轮显式设置 research_mode=deep_research 启动。它不作为普通 Chat 中可由模型自行调用的 research_start 工具；ExternalCapabilityAvailability 明确把该 capability 保持为关闭。

~~~mermaid
flowchart TB
    U["用户输入"] --> M{"是否显式开启 Deep Research"}
    M -->|"否"| CHAT["普通 Chat<br/>可读取 Memory / Shelf<br/>可做个性化推荐"]
    M -->|"是"| DR["DeepResearchRunner"]
    DR --> PLAN["ResearchObjectivePlan<br/>UserAnswerBrief + 候选假设 + EvidenceStrategy"]
    PLAN --> SEARCH["围绕结论缺口的并行多轮检索"]
    SEARCH --> QUALITY["内容质量检查与 claim 提取"]
    QUALITY --> ADMIT["证据准入、缺口与冲突"]
    ADMIT --> REVIEW["Reviewer 与停止条件"]
    REVIEW --> PACKET["ResearchPublicationPacket<br/>用户决策资料包"]
    PACKET --> REPORT["最终编辑综合与 Markdown 发布"]
    REPORT --> STORE["ResearchRun / Step / Evidence / Snapshot"]
~~~

### 7.2 研究循环

当前 DeepResearchRunner 采用有界多轮研究：

- 最多 3 个搜索回合；
- 每回合最多 8 个搜索结果和 8 条记录；
- 建立 ResearchRun；
- 模型先形成用户回答目标、候选假设组合和按问题类型自适应的证据面；
- 通过 SearchGateway 获取来源；
- 做内容垃圾检查、claim 提取和证据准入；
- 维护 known facts、gaps、conflicts、exhausted queries 和 next actions，并根据结论缺口决定下一轮查询，而不是机械重复 Search；
- 把候选判断、证据覆盖、来源索引、冲突和用户相关限制投影成 ResearchPublicationPacket；
- 最终报告模型只负责面向用户的编辑综合，不再规划、检索或输出内部思考过程；
- 最终把结论、来源数、证据数和运行状态写回 ResearchRun。

对于推荐型研究，候选组合可以来自模型的稳定知识，外部材料用于校验候选的内容定位、实践性、评价、教程/代码资源和当前信息。某个候选暂时找不到足够外部证据时，系统应降低该候选的证据置信度并诚实说明缺口，而不是仅因检索缺失就把模型候选全部删掉。PublicationPacket 因此同时保留 model rationale 与 external evidence status，避免“候选/证据 → 最终答案”过程中发生信息损失。

发布验收分为两个轴：publication safety 处理实体越界、URL、空输出和推理泄漏；answer quality 检查是否直接回应用户、覆盖目标候选和关键取舍。质量不足可以触发一次受限修复，但不应因为非安全性的格式偏差把已有可用答案直接降级成错误弹层。JSON 是内部结构协议；最终用户输出以 Markdown 为主，模型不支持特定结构化响应模式时也不应因此失去完整答案。

Research 报告默认 personalization_mode=off，不会自动读取 Memory 或 Shelf。代码保留 explicit 个性化报告模式，但当前用户主链的 Deep Research 不默认开启它。因此不能写成“所有深度研究都会根据用户偏好定制”。

### 7.3 Research 前端

前端研究视图支持：

- 按全部、进行中、已完成、已停止、失败筛选 ResearchRun；
- 查看研究目标、状态与时间；
- 查看步骤、耗时、错误；
- 查看证据 claim、摘要、质量、相关度、来源链接和 provider 原始数据；
- 查看已知事实、证据缺口、冲突和验证准入统计；
- 停止仍处于 active 状态的运行。

研究结果的可信度取决于可访问来源与证据质量。系统实现了准入和不确定性表达，但不能保证互联网信息天然正确，也不能替代人工学术审稿。

---

## 8. 前端功能

前端使用 React 单页应用，主要工作区包括：

| 页面/组件 | 当前真实功能 |
|---|---|
| 登录/身份选择 | 获取模拟用户、模拟登录和退出；用户空间决定会话、记忆、书架与研究归属 |
| Chat | 新建/切换/重命名/删除会话，SSE 流式消息，Markdown/代码展示，引用消息，模型与思考模式选择 |
| Deep Research 开关 | 每次发送时显式决定 research_mode，不会让普通聊天自动升级为研究 |
| 我的书架 | 添加书名、状态筛选、标题/作者搜索、修改状态、评价、备注、删除、显示作者和本地缓存封面 |
| 当前记忆 | 按用户语义分类查看有效 Memory、兼容历史、编辑和遗忘；技术 schema/key 不作为默认用户信息展示 |
| 研究视图 | ResearchRun 列表、详情、证据、步骤、缺口、冲突和停止操作 |
| 执行 DAG | 按 thread/request 查看步骤和节点详情，流式期间合并 live steps |
| Token 统计 | 展示会话和聚合用量数据 |
| 模型/Provider 配置 | 连接、模型增删改、默认模型、thinking 标志、激活状态、能力校验、应用级 provider 健康检查 |
| 微信入口 | 二维码图片与 WebSocket 授权通道；是否可用取决于本地微信集成环境 |

当前 Bookshelf 前端不是只读展示，它通过 ReadingService 对应 REST API 完成增删改。计数显示需要注意：状态标签上的分项计数基于当前已加载结果，而“全部”来自服务端 total；筛选状态下不能把各标签数字解释为全库统计。

---

## 9. 后端技术栈与工程结构

### 9.1 技术栈

| 层次 | 当前依赖 |
|---|---|
| 前端 | React 19.2、TypeScript 5.9、Vite 8、React Router 7、Tailwind CSS 4、Radix UI、TipTap、Recharts、Marked/React-Markdown、Shiki |
| 后端 API | Python、FastAPI 0.121、Uvicorn 0.38、Pydantic |
| Agent/LLM | LangChain 1.3、LangGraph 1.2、LiteLLM adapter、LangSmith |
| 数据库 | PostgreSQL、SQLAlchemy Async、asyncpg、psycopg、pgvector/LangChain Postgres |
| 外部检索 | Tavily、DDGS、AnySearch 适配器；统一由 SearchGateway 编排 |
| 网络与通道 | aiohttp、WebSocket、SSE |
| 认证基础 | JWT 依赖、模拟登录；当前用户主流程仍以 mock user 为主 |

### 9.2 关键目录

~~~text
backend/app/api/v1/                     REST、SSE、WebSocket 入口
backend/app/services/agent_core/       Controller、capability、编译、执行、发布
backend/app/services/memory/           Memory Gateway、版本链、Entity、Provider
backend/app/services/books/            Reading、Recommendation、元数据缓存
backend/app/services/research/         研究循环、证据、校验、报告
backend/app/services/external_search/  搜索 Gateway 与 Provider
backend/app/models/                    SQLAlchemy ORM 模型
backend/scripts/sql/                   初始化和 change_001..change_037
backend/tests/                         确定性单元/架构测试
backend/scripts/                       流程验证和真实外部 E2E
frontend/src/features/                 chat、bookshelf、research、kanban
docs/                                  架构契约和论文事实材料
~~~

---

## 10. 数据库设计

### 10.1 数量口径

当前 SQLAlchemy Base.metadata 注册 27 张应用 ORM 表。加上 SQL 初始化/迁移明确维护的 6 张向量与 embedding 基础表，固定 schema 的净结果为 33 张表。LangGraph checkpoint 还可能由依赖在运行时管理自己的表，因此论文中必须说明统计口径，不能只写一个不带口径的“数据库共有 N 张表”。

backend/scripts/sql 包含 change_001 至 change_037 共 37 个顺序迁移文件。历史上创建后又删除的 shadow/certification 表不计入当前净表数。

### 10.2 27 张应用 ORM 表

| 分类 | 表 |
|---|---|
| 用户与配置（7） | users、user_channels、providers、provider_connections、models、model_capability_checks、app_provider_configs |
| 会话与观测（4） | conversations、conversation_events、conversation_summaries、trace_executions |
| Memory/Entity（3） | memory_events、memory_entities、memory_management_events |
| 图书/阅读/推荐（6） | books、book_interactions、recommendation_events、user_preference_profiles、user_book_shelf、user_bookshelf_state |
| Research（4） | research_runs、research_steps、research_evidence、research_state_snapshots |
| Task（3） | task_states、task_plan_versions、action_execution_receipts |

### 10.3 6 张固定基础设施表

- langchain_pg_collection
- langchain_pg_embedding
- embedding_spaces
- embedding_space_bindings
- embedding_calibration_reports
- embedding_space_activations

### 10.4 关键数据关系

~~~mermaid
erDiagram
    USERS ||--o{ CONVERSATIONS : owns
    USERS ||--o{ MEMORY_EVENTS : owns
    USERS ||--o{ MEMORY_ENTITIES : owns
    USERS ||--o{ USER_BOOK_SHELF : owns
    USERS ||--o{ RECOMMENDATION_EVENTS : produces
    USERS ||--o{ RESEARCH_RUNS : starts

    CONVERSATIONS ||--o{ CONVERSATION_EVENTS : journals
    CONVERSATIONS ||--o{ CONVERSATION_SUMMARIES : compresses
    CONVERSATIONS ||--o{ TRACE_EXECUTIONS : traces

    MEMORY_ENTITIES ||--o{ MEMORY_EVENTS : binds
    MEMORY_EVENTS ||--o| MEMORY_EVENTS : supersedes

    BOOKS ||--o{ USER_BOOK_SHELF : references
    BOOKS ||--o{ BOOK_INTERACTIONS : receives
    BOOKS ||--o{ RECOMMENDATION_EVENTS : signals

    RESEARCH_RUNS ||--o{ RESEARCH_STEPS : contains
    RESEARCH_RUNS ||--o{ RESEARCH_EVIDENCE : admits
    RESEARCH_RUNS ||--o{ RESEARCH_STATE_SNAPSHOTS : versions

    TASK_STATES ||--o{ TASK_PLAN_VERSIONS : revises
    TASK_STATES ||--o{ ACTION_EXECUTION_RECEIPTS : executes
~~~

图中没有展示所有可空外键和复合唯一约束，只表达论文需要的主要领域关系。

---

## 11. API 结构

运行时枚举并排除 /openapi.json、Swagger 和 ReDoc 后，当前应用共有 70 个 FastAPI 路由，其中 69 个 HTTP 路由和 1 个 WebSocket 路由。

| 分组 | 数量 | 主要入口 |
|---|---:|---|
| Health | 1 | GET /health |
| Auth | 4 | status、mock-users、mock-login、logout |
| Books | 13 | 本地列表、公共搜索、交互/推荐事件、偏好、Shelf CRUD、封面、书籍详情 |
| Chat | 13 | invoke、stream、conversation CRUD/info/title、history、daily/usage/model stats |
| Memory | 4 | current、history、edit、forget |
| Models | 13 | model CRUD/validate/capabilities、provider、connection、thinking-mode |
| App Provider Config | 4 | list/detail/update/health |
| Research | 9 | runs、detail、report、start、search、visit、evidence、state、finish |
| Traces | 7 | list、steps、DAG、单步、checkpoint、replay |
| WeChat | 2 | QR image、WebSocket auth |

API 中的 Research start/search/visit/evidence/state/finish 既支持 DeepResearchRunner，也支持对研究状态进行显式生命周期操作。它们不是普通 Chat 自动执行的隐藏研究路径。

---

## 12. 架构防回归与 legacy 处置

### 12.1 常驻架构门禁

backend/tests/test_memory_architecture.py 使用 AST 和静态导入检查，而不是只依赖脆弱的全文搜索。它当前约束：

1. version_runtime 只能消费 Controller assertions，不得再启动第二个语义编译器；
2. MemoryVersionStore.commit 只能从 write_gateway.py 调用；
3. 旧 canonicalizer 只有有限的管理/影子/离线分析 allowlist；
4. Memory Provider 拒绝缺少 domain/kind/entity_id 的越级数据；
5. Reading 派生 Memory 必须调用 MemoryWriteGateway；
6. Agent Core、API、Chat、Reading 和 Recommendation 等生产面不得 import deprecated baseline；
7. 业务层不得直接 import Memory Store/Provider，allowlist 只保留 Gateway 和隔离兼容模块；
8. 应用代码不得对 memory_events、user_book_shelf、recommendation_events、book_interactions 写 raw SQL；
9. VersionStore/Provider 不得 import LLM、semantic interpreter 或 turn compiler；
10. Shelf read 必须使用 ReadingService，且不得回退 Memory；Book runtime adapter 必须委托 RecommendationService。

这些测试能防止最关键的 Memory/Reading/Recommendation 旁路重新进入生产，但不能自动证明整个系统所有业务语义都正确；黑盒 E2E 仍然需要。

### 12.2 Legacy 清单

| 组件 | 当前状态 | 论文中应如何描述 |
|---|---|---|
| write_coordinator.py / MemoryCommitter | deprecated compatibility | 代码保留，但生产 Agent Core、Chat、API、Tool 不得 import |
| process_memory_write_request 与旧 routing/planning | deprecated compatibility | 旧离线/兼容模块可见，SystemRuntime 当前不注册为生产能力 |
| 旧 Memory canonicalizer | normalizer/管理适配 | 不能直接写 Store；只在 allowlist 场景规范化数据 |
| 旧 LangGraph book tools | compatibility | 当前 Chat 推荐由 RecommendationService 承担 |
| 历史 shadow/certification 表 | 已由迁移删除 | 不属于当前数据库净结构 |

仓库中搜索到旧模块名并不等于生产仍有第二条基线。判断依据是生产入口导入图、Capability Registry、Runtime 注册和架构测试，而不是简单删除所有历史文件。

---

## 13. 测试与当前可复核证据

### 13.1 确定性测试

当前 backend/tests 有 75 个 `test_*.py` 模块。以生产实现提交 `054198d` 的代码执行：

~~~text
cd backend
.venv/Scripts/python.exe -m pytest -q
691 passed, 38 subtests passed
~~~

覆盖范围包括 Agent Core、Controller contract、Search Provider 融合、用户回答契约、发布安全、Memory 系统执行与当前投影、Reading 多动作、Bookshelf read、Recommendation projection、Deep Research 候选发现/缺口循环/PublicationPacket/证据准入、SSE 可信发布、任务状态、Provider、Embedding 和架构边界。

### 13.2 流程验证脚本

backend/scripts 当前有 104 个 verify_*.py，包括：

- verify_reading_effect_e2e.py
- verify_bookshelf_read_e2e.py
- verify_deep_research_routing_http_flow.py
- verify_external_search_live.py
- verify_controller_capability_live.py
- verify_research_*
- verify_recommendation_*
- verify_release_gates.py

这些脚本混合了本地确定性流程和真实外部依赖验证。论文不能写“104 个 E2E 全部稳定通过”，除非在答辩前对固定环境重新逐项执行并保存日志。

### 13.3 前端构建

当前基准执行 npm run build 已通过 TypeScript 和 Vite 生产构建，最近一次处理 2550 个模块。聊天、书架、研究视图和 Markdown 渲染已按 chunk 输出；最大生成 chunk 约 779.90 kB（gzip 约 197.59 kB）。构建可交付，但仍不能宣称前端包体已经完成系统性性能优化。

### 13.4 真实集成证据与边界

当前本地数据库、Shelf API、作者补全、本地封面下载、后端封面接口以及 Vite 代理链已做过真实联调并返回成功。自然语言多表达 E2E 依赖真实 LLM；完整运行曾通过批量表达，但后续也出现过外部模型超时，因此应把它作为效果验证而不是离线确定性证明。

建议答辩前固定模型、温度、数据库快照和网络条件，重新执行至少 30 组不重叠自然表达，记录：动作准确率、实体准确率、Shelf 最终状态准确率、Memory 投影准确率、重复推荐率和 Deep Research 误触发率。

---

## 14. 当前明确限制与未实现项

以下内容不能为了论文完整而写成已实现：

1. **不是生产级统一认证系统。** 当前 Web 主流程使用 mock user/mock login；虽有 JWT 依赖与微信通道，但没有完整 OAuth、RBAC、租户隔离和安全审计闭环。
2. **不是所有模型都可无配置使用。** Chat 需要至少一个可用 LLM；工具调用和 thinking 能力取决于模型，系统提供 capability validation，但无法把不支持工具的模型变成支持工具的模型。
3. **Embedding 默认没有自动开启。** 项目有 embedding space、校准、绑定和 pgvector 组件，但默认配置下 Memory embedding 可关闭，不能把所有 Memory 查询描述成向量检索。
4. **Deep Research 不保证学术正确。** 它提供多轮搜索、证据准入、缺口和冲突表达，但来源质量、网页可访问性和模型综合仍有限制。
5. **Deep Research 默认不个性化。** 这是隔离设计，不是缺陷；普通推荐才读取 Memory/Shelf。
6. **书籍作者与封面不是全量书目数据库。** 当前通过公开豆瓣页面一次性补全和本地缓存，可能找不到、误匹配或受页面变化影响。
7. **Shelf 与派生 Memory 没有跨事务 outbox。** Shelf 是权威状态，Memory 投影失败时可能暂时缺失。
8. **底层 interaction/event API 仍存在。** 它们记录信号，不等价于修改 Shelf；论文不能把所有 event 写入都称为阅读状态更新。
9. **Task 持久化与恢复主要是内部 Agent 能力。** 默认任务恢复开关并非普通用户主功能，前端也没有完整的通用任务管理工作台。
10. **没有已完成的推荐算法对比实验。** 如果论文声称“准确率提升”“显著优于某算法”，必须补实验数据，当前代码和单元测试不能支持该结论。
11. **没有分布式高可用部署证据。** 当前是单体 FastAPI + React + PostgreSQL 架构，没有 Kubernetes、多区域容灾或大规模并发压测结果。
12. **前端仍有包体优化空间。** 构建可用，但仍存在较大的 Markdown 相关 chunk，需要继续评估按需加载与依赖拆分。
13. **当前 Memory 兼容收敛是读侧投影，不是物理迁移。** 历史重复 key 仍保留以便审计；论文不能把它描述成数据库已经完成全量清洗。
14. **模型知识与外部证据的边界依赖发布提示和验收。** 系统已防止因来源不足机械删除全部候选，但仍需通过固定问题集评估模型判断、证据核验与最终答案之间的真实增益。

---

## 15. 可用于论文的技术特点

以下特点有当前代码支撑，可以作为设计与实现章节的重点，但建议使用“设计并实现”而不是“行业首创”：

1. **效果驱动的单语义、多动作执行。** 一条自然语言可生成多个独立结构化 assertion，并批量映射到不同书籍状态和评价；写侧不再二次 LLM 解释。
2. **Memory 与 Shelf 的双事实源分工。** Memory 管长期偏好和事实，Shelf 管当前阅读资产，通过派生投影联系但不互相替代。
3. **版本化长期记忆。** 使用 memory key、current head、supersede 和 tombstone 支持纠正、历史和遗忘。
4. **实体绑定减少同名/异名碎片。** 先通过 EntityResolver 绑定稳定实体，再生成实体级 memory key。
5. **模型候选与工具核验协同的个性化推荐。** Controller 直接读取有界 Shelf 快照产生候选，RecommendationService 合并长期偏好、完整 Shelf、阅读锚点和行为事件，外部检索增加信息，发布守卫保留已核验候选。
6. **普通推荐与 Deep Research 隔离。** 研究只由用户显式开启，默认不受个性化记忆干扰。
7. **有界研究与证据发布。** 研究状态显式保存步骤、证据、缺口、冲突、停止条件和报告准入结果。
8. **回执支持的可信发布。** Controller 只提议，执行结果形成 typed receipt，最终答案可以关联执行证据。
9. **本地封面缓存。** 从公开页面解析一次后按内容哈希缓存，减少对第三方图床的长期依赖。
10. **AST 架构门禁。** 通过依赖 allowlist、import graph 和 AST raw-SQL 检查防止旧写入基线回流。
11. **模型智能与工具信息解耦。** UserAnswerBrief、EvidenceStrategy 和 PublicationPacket 分别约束用户目标、证据问题和最终输入；候选判断不会被检索覆盖率机械替代。
12. **非破坏性记忆兼容投影。** 当前语义槽、版本续链和结构化 summary 清理在读写边界完成，保留历史的同时避免旧事实污染当前回答。

---

## 16. 交给论文写作者的结构化说明

### 16.1 推荐论文题目

可选题目：

1. 《基于大语言模型与版本化记忆的个性化阅读助手设计与实现》
2. 《融合用户书架、长期记忆与证据研究的智能阅读助手设计与实现》
3. 《面向阅读场景的多动作语义执行与个性化推荐系统设计》

最贴近当前实现的是第 2 个。若论文重点放在 Agent 架构，可选择第 1 个；若重点放在“自然语言自动更新书架”，可选择第 3 个。

### 16.2 一句话系统定义

本系统是一个面向阅读场景的 Web 智能助手：它使用大语言模型把用户自然语言转换为受约束的结构化动作，通过唯一领域服务更新版本化长期记忆和权威书架，并在普通推荐中融合用户偏好与阅读状态，同时提供默认隔离的证据型 Deep Research 流程。

### 16.3 摘要可使用的事实骨架

论文摘要可以按以下逻辑编写：

1. **问题背景：** 普通聊天机器人对用户阅读历史缺少稳定管理，易重复推荐已知书；仅靠自然语言记忆也难以回答准确书架状态。
2. **设计方法：** 将语义理解、领域决策、版本持久化分层；以 MemoryWriteGateway、ReadingService、RecommendationService 和 ResearchRun 为核心边界。
3. **关键实现：** 单次语义输出多个 assertion；Memory 版本链与实体绑定；Shelf current view；Memory + Shelf 推荐投影；显式触发、有界循环的 Deep Research；SSE/Trace 可观测性。
4. **工程保障：** PostgreSQL 持久化、typed receipt、AST 架构测试、单元测试与黑盒自然语言 E2E。
5. **结果表述：** 当前基准 691 个后端测试与 38 个子测试通过，前端生产构建通过；真实外部能力的稳定性受模型和网络约束。

不要在没有实验数据时写“推荐准确率提高 X%”“达到毫秒级”“可支持万级并发”。

### 16.4 建议章节结构

#### 第一章 绪论

- 阅读助手、个性化推荐、长期记忆和研究型 Agent 的背景；
- 传统聊天历史、单一记忆库和规则意图识别的不足；
- 项目目标与本文工作；
- 研究内容：多动作语义执行、双事实源、推荐隔离、证据研究和架构门禁。

#### 第二章 相关技术

- FastAPI、React、SSE；
- LLM tool calling 与结构化输出；
- PostgreSQL、版本链和 pgvector；
- Agent Controller/Compiler/Runtime；
- 检索、证据准入和研究报告；
- 不要把框架功能直接写成项目创新。

#### 第三章 需求分析

- 用户角色与 mock 身份边界；
- 功能需求：Chat、Memory、Bookshelf、Recommendation、Deep Research、配置与 Trace；
- 非功能需求：可追溯、幂等、无重复推荐、架构可维护、失败可解释；
- 用例重点：复合阅读表达、书架问答、普通推荐、显式研究。

#### 第四章 系统设计

- 使用本文 2.2 总体组件图；
- 领域 Owner 与 Source of Truth 表；
- Memory/Reading 统一写入图；
- 普通推荐与 Deep Research 分叉图；
- 数据库分类和核心 ER 图；
- provenance、typed receipt 与错误边界。

#### 第五章 系统实现

- ChatService 和 AgentControllerGateway；
- Controller 多 assertion 与编译；
- MemoryWriteGateway、EntityResolver、MemoryVersionStore；
- ReadingService、Shelf current view 和派生 Memory；
- RecommendationService 的约束、排除和投影；
- DeepResearchRunner 的循环、证据与报告；
- BookMetadata 与本地封面缓存；
- 前端 Chat、Bookshelf、Research、Trace。

#### 第六章 测试与结果分析

- 单元测试与架构测试；
- 复合自然语言黑盒测试；
- Shelf/Memory 最终数据库状态核验；
- 已知书重复推荐率；
- Deep Research 显式触发与误触发测试；
- 外部超时、封面失败、模型不支持 tool calling 等异常测试；
- 如需推荐效果结论，新增可复现对照实验。

#### 第七章 总结与展望

- 总结已经实现的主链；
- 展望 outbox 补偿、认证权限、推荐离线评测、书目数据源、前端分包和部署扩展；
- 不要把展望写成现有功能。

### 16.5 推荐实验设计

#### 实验 A：多动作语义稳定性

- 准备至少 30 条不同自然表达；
- 每条包含 1～4 本书、状态、评价、纠正或否定；
- 固定代码、模型、温度和数据库初始状态；
- 评价 assertion 召回率、错误动作率、实体绑定准确率和最终 Shelf 状态准确率；
- 测试数据不得把具体句子写入规则代码。

#### 实验 B：书架读取正确性

- 先通过 Chat、REST 和 correction 三种来源构造 Shelf；
- 再用不同问法询问数量、状态和评价；
- 以 user_book_shelf 数据库快照为金标准；
- 验证回答不从重复 Memory 文本拼接。

#### 实验 C：重复推荐抑制

- 为用户构造四种 Shelf 状态；
- 发起多轮推荐；
- 统计候选中已知书出现率；
- 对照关闭 Shelf projection 的实验版本；
- 区分 lookup 查询与 recommendation 请求。

#### 实验 D：Deep Research 隔离

- 同一问题分别以普通 Chat 和显式 Deep Research 发起；
- 检查是否建立 ResearchRun、是否产生 evidence/steps；
- 检查默认 report 的 memory_context 为空；
- 统计普通 Chat 误启动研究的次数。

#### 实验 E：异常与降级

- 模型超时；
- 搜索 Provider 不可用；
- 豆瓣页面不可用；
- Memory 投影失败；
- 同名实体歧义；
- 验证系统是否保留 Shelf 权威状态并返回可解释错误。

### 16.6 安全表述、条件表述与禁止表述

| 类型 | 可用表述 |
|---|---|
| 安全 | “系统实现了版本化长期记忆和权威书架的分离管理。” |
| 安全 | “同一轮语义输出可以包含多条结构化业务 assertion。” |
| 安全 | “普通推荐融合 Memory 与 Shelf，并排除所有已知 Shelf 状态。” |
| 安全 | “Deep Research 由用户显式开启，默认不读取个性化 Memory。” |
| 条件 | “在模型、数据库和搜索服务可用时，系统可以完成端到端研究流程。” |
| 条件 | “对可成功匹配的豆瓣页面，系统可解析作者并缓存封面。” |
| 禁止 | “系统使用官方豆瓣 API。”当前实现是公开页面解析，不是官方 API |
| 禁止 | “所有用户表达都能 100% 正确理解。”没有这样的证明 |
| 禁止 | “所有 Deep Research 结论都真实可靠。”系统只能降低风险，不能保证事实 |
| 禁止 | “Memory 与 Shelf 始终强一致。”REST 派生 Memory 当前是 best-effort |
| 禁止 | “全部 104 个 E2E 长期稳定通过。”外部依赖验证不能这样概括 |
| 禁止 | “系统已支持生产级多租户和高并发部署。”当前没有证据 |

### 16.7 论文证据索引

论文作者遇到疑问时应优先查阅：

| 主题 | 代码/文档位置 |
|---|---|
| 总体架构契约 | docs/SYSTEM_ARCHITECTURE.md |
| 论文实现证据包 | docs/thesis_materials/README.md、docs/thesis_materials/00_verified_technical_facts.md |
| Shelf 契约 | docs/bookshelf-contract.md |
| Chat 主入口 | backend/app/services/chat.py |
| Agent 生产边界 | backend/app/services/agent_core/gateway.py |
| Controller 与工具 schema | backend/app/services/agent_core/controller_client.py、capabilities.py |
| 多 assertion 编译 | backend/app/services/memory/turn_compiler.py |
| 统一 Memory 写入 | backend/app/services/memory/write_gateway.py |
| 模型事实确定性执行 | backend/app/services/memory/model_fact_executor.py |
| Memory 当前语义投影 | backend/app/services/memory/current_projection.py、admin_projection.py |
| Memory 版本持久化 | backend/app/services/memory/version_store.py |
| Entity | backend/app/services/memory/entity_resolver.py |
| Reading/Shelf | backend/app/services/books/reading_service.py |
| 推荐上下文 | backend/app/services/agent_core/request_builder.py、prompt_contracts.py、prompt_composer.py |
| 推荐执行与排重 | backend/app/services/recommendation_constraints.py、backend/app/services/books/recommendation_service.py、recommendation_projection.py |
| 推荐可信发布 | backend/app/services/agent_core/publication/service.py、evidence_fallback.py |
| 用户回答与证据策略 | backend/app/services/user_answer_contracts.py、evidence_strategy.py |
| 作者/封面 | backend/app/services/books/book_metadata.py |
| Deep Research | backend/app/services/research/deep_research_runner.py |
| Research 发布资料包与质量 | backend/app/services/research/publication/packet.py、quality.py、semantic_quality.py、report_writer.py |
| Research 状态 | backend/app/services/research/orchestrator.py、report.py |
| API | backend/app/api/v1 |
| ORM | backend/app/models |
| 数据库迁移 | backend/scripts/sql |
| 架构门禁 | backend/tests/test_memory_architecture.py |
| 效果驱动测试 | backend/tests/test_effect_driven_reading.py、test_recommendation_control_flow.py、test_r5_trusted_publication.py、test_chat_conversation_race.py |
| 前端书架 | frontend/src/features/bookshelf/components/bookshelf-view.tsx |
| 前端研究 | frontend/src/features/research/components/research-view.tsx |

---

## 17. 最终结论

当前项目已经形成一条可清楚解释的主架构：普通 Chat 用 Controller 完成自然语言理解和结构化动作提议；Search 用一次理解、联合检索和一次综合快速增强回答；MemoryWriteGateway 与 ReadingService 分别守住长期记忆和阅读资产边界；普通推荐让 Controller 直接读取有界 Shelf 快照产生候选，再由 RecommendationService 融合完整 Memory、Shelf 与外部核验并排除已知书，发布守卫防止已核验候选被静默压缩；DeepResearchRunner 则在用户显式开启后围绕结论缺口开展独立研究，并通过 PublicationPacket 把模型判断与外部证据交给最终编辑模型。数据库、版本链、事件、Trace 和架构测试为这些链路提供可追溯性。

论文最值得论述的不是“调用了大模型”，而是如何让模型负责产生智能、让工具负责增加信息，并把两者约束成可验证、可持久化、可回归且最终对用户有价值的业务效果。与此同时，论文必须如实保留当前限制：外部依赖并非始终可用、认证尚未生产化、书目元数据并非官方 API、REST Shelf 到 Memory 是 best-effort 投影、Memory 旧链尚未物理迁移、推荐与研究质量还缺少正式对照实验。
